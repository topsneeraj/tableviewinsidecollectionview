//
//  ViewController.swift
//  tableviewdemo
//
//  Created by TOPS on 6/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate {

     let arr = ["10.jpg","22.jpg","10.jpg","22.jpg","10.jpg","22.jpg","10.jpg","22.jpg"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6;
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if indexPath.row == 0 || indexPath.row == 3 {
            
             let cell1 = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! cell1
            
            cell1.img.image = UIImage(named: "3.png");
            
            
            
            return cell1;
        }
        
        
       else if indexPath.row == 1 || indexPath.row == 4 {
            
            
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! cell2
            
            cell2.coll.reloadData();
            

            return cell2;
            
            
            
            
        }
        
        else
        {
            
            let cell3 = tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath) as! cell3
            
            cell3.img1.image = UIImage(named: "3.png");
            cell3.img2.image = UIImage(named: "3.png");
        
            return cell3;
            
            
        }
        
    
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1;
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        return  arr.count;
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collcell", for: indexPath) as! custcell;
        
        cell.collimg.image = UIImage(named: arr[indexPath.row]);
        
        return cell;
        
        
        
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

