//
//  cell2.swift
//  tableviewdemo
//
//  Created by TOPS on 6/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class cell2: UITableViewCell {

    @IBOutlet weak var coll: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
